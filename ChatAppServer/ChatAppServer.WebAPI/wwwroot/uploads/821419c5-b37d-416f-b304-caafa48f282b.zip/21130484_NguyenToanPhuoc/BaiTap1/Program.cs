﻿using System;
namespace app {
    class BaiTap_day_1 {

        public static void baiTap_01() {
            Console.Write("Moi ban nhap so phan tu cua mang: ");
            int length = int.Parse(Console.ReadLine());
            int[] arr = new int[length];
            for (int i = 0; i < length; i++) {
                Console.Write("Moi ban nhap phan tu thu " + (i+1)  +" cua mang: ");
                arr[i] = int.Parse(Console.ReadLine());
            }
            Console.Write("Mang: ");
            foreach(int num in arr) {
                Console.Write(num + " ");
            }
        }

        public static void baiTap_02() {
            int sum = 0;
            Console.Write("Moi ban nhap so phan tu cua mang: ");
            int length = int.Parse(Console.ReadLine());
            int[] arr = new int[length];
            for (int i = 0; i < length; i++) {
                Console.Write("Moi ban nhap phan tu thu " + (i+1)  +" cua mang: ");
                sum+= int.Parse(Console.ReadLine());
            }
            Console.Write("Tong cua mang: " + sum);
        }

        public static int[] BaiTap_03(int[] arr) {
            int[] re = new int[arr.Length];
            for(int i = 0; i < arr.Length; i++) {
                re[i] = arr[i];
            }
            return re;
        }
    };

    class Test {
        static void Main(String[] args) {
            int[] arr = {1, 2, 3, 4};
            Console.WriteLine(String.Join(", ", BaiTap_day_1.BaiTap_03(arr)));
        }
    }
}
