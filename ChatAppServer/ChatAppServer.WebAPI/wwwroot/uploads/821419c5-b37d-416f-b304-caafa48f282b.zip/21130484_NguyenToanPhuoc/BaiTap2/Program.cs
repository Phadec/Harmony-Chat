﻿
using System.Collections;

namespace BaiTap02
{
    class BaiTap02
    {
        public static bool kiemTraSoNguyenTo(int number)
        {
            if (number < 2) return false;
            for (int i = 2; i <= Math.Sqrt(number); i++)
            {
                if (number % i == 0)
                {
                    return false;
                }
            }
            return true;
        }

        public static void inSoNguyenTo(int[,] matrix)
        {
            Console.Write("So cac so nguyen to trong ma tran nay la: ");
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    if (kiemTraSoNguyenTo(matrix[i,j]))
                    {
                        Console.Write(matrix[i,j] + " ");
                    }
                }
            }
        }

        public static void tinhTongSoTrenTungHang(int[,] matrix)
        {
            
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                Console.Write("Tong cac so tren hang {0}: ", i+1); 
                int sum = 0; 
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    sum+= matrix[i,j];
                }
                Console.WriteLine(sum);
            }
        }

        public static void inCacPhanTuNgoaiBien(int[,] matrix)
        {
            int sum = 0;
            Console.Write("Cac phan tu ngoai bien cua ma tran la: ");
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    if (i == 0 || j == 0 || i == matrix.GetLength(0) -1 || j == matrix.GetLength(1) -1)
                    {
                        Console.Write(matrix[i, j] + " ");
                        sum += matrix[i, j];
                    }
                }
            }
            Console.WriteLine();
            Console.WriteLine("Tong cac phan tu nam ngoai bien cua ma tran la: " + sum);
        }

        public static void soLonNhatTrenDong(int[,] matrix)
        {
            for (int i = 0;i < matrix.GetLength(0); i++)
            {
                int max = matrix[i, 0];
                Console.Write("So lon nhat tren dong {0}: ", i+1);
                for(int j = 0; j < matrix.GetLength(1); j++)
                {
                    if (max < matrix[i, j])
                    {
                        max = matrix[i, j];
                    }
                }
                Console.WriteLine(max);
            }
        }

        public static void soNhoNhatTrenCot(int[,] matrix)
        {
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                int min = matrix[0, i];
                Console.Write("So nho nhat tren cot {0}: ", i+1);
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    if (min > matrix[j, i])
                    {
                        min = matrix[j, i];
                    }
                }
                Console.WriteLine(min);
            }
        }


        public static void Main(string[] args)
        {
            Console.Write("Nhap so dong cua ma tran: ");
            string? row = Console.ReadLine();
            Console.Write("Nhap so cot cua ma tran: ");
            string? column = Console.ReadLine();
            int[,] matrix = new int[int.Parse(column), int.Parse(row)];
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write("Moi ban nhap phan tu cua matrix[{0}, {1}] = ", i, j);
                    matrix[i, j] = int.Parse(Console.ReadLine());
                }
            }
            Console.WriteLine("Ma tran ban vua nhap la: ");
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write(matrix[i, j] + " ");
                }
                Console.WriteLine();
            }
            inSoNguyenTo(matrix);
            Console.WriteLine();
            tinhTongSoTrenTungHang(matrix);
            Console.WriteLine();
            inCacPhanTuNgoaiBien(matrix);
            Console.WriteLine();
            soLonNhatTrenDong(matrix);
            Console.WriteLine();
            soNhoNhatTrenCot(matrix);
        }
    }
}
