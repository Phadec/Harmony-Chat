﻿namespace BaiTap03
{
    class VeMayBay
    {
        public string TenChuyen { set; get; }
        public DateTime NgayGioBay { set; get; }
        public double GiaVe { set; get; }

        public VeMayBay(string tenChuyen, DateTime ngayGioBay, double giaVe)
        {
            this.TenChuyen = tenChuyen;
            this.NgayGioBay = ngayGioBay;
            this.GiaVe = giaVe;
        }

        public double getGiaVe()
        {
            return this.GiaVe;
        }
    }

    class ConNguoi
    {
        public string HoTen { set; get; }
        public string GioiTinh { set; get; }
        public int Tuoi { set; get; }

        public ConNguoi(string hoTen, string gioiTinh, int tuoi)
        {
            this.HoTen = hoTen;
            this.GioiTinh = gioiTinh;
            this.Tuoi = tuoi;
        }
    }

    class HanhKhach : ConNguoi
    {
        public VeMayBay ve { set; get; }
        public int soLuong { set; get; }
        public HanhKhach(string hoTen, string gioiTinh, int tuoi,VeMayBay ve, int soLuong) : base(hoTen, gioiTinh, tuoi)
        {
            this.ve = ve;
            this.soLuong = soLuong;
        }

        public double tongTien()
        {
            double tongTien = this.ve.getGiaVe() * soLuong;
            if (this.ve.NgayGioBay.Month == 10 )
            {
                tongTien *= 0.9;
            }

            return tongTien;
        }
    }

    class Program
    {
        public static void Main(string[] args)
        {
            List<HanhKhach> list = new List<HanhKhach> ();
            Console.WriteLine("Nhap so luong hanh khach: ");
            int number = int.Parse(Console.ReadLine());
            for (int i = 1; i <= number; i++)
            {
                Console.WriteLine("Nhap thong tin hanh khach thu {0}: ", i);
                Console.WriteLine();
                Console.Write("Ho ten: ");
                string hoTen = Console.ReadLine();

                Console.Write("Gioi tinh: ");
                string gioiTinh = Console.ReadLine();

                Console.Write("Tuoi: ");
                int tuoi = int.Parse(Console.ReadLine());

                Console.Write("Ten chuyen bay: ");
                string tenChuyen = Console.ReadLine();

                Console.Write("Ngay gio bay (yyyy-MM-dd HH:mm): ");
                DateTime ngayGioBay = DateTime.Parse(Console.ReadLine());

                Console.Write("Gia ve: ");
                double giaVe = double.Parse(Console.ReadLine());

                Console.Write("So luong ve: ");
                int soLuong = int.Parse(Console.ReadLine());

                VeMayBay ve = new VeMayBay(tenChuyen, ngayGioBay, giaVe);
                HanhKhach hanhKhach = new HanhKhach(hoTen, gioiTinh, tuoi, ve, soLuong);

                list.Add(hanhKhach);
            }

            var sortList = list.OrderBy(hk => hk.HoTen.Split(" ").Last()).ToList();
            Console.WriteLine("Danh sach hanh khach va so tien phai tra: ");
            foreach(var hanhKhach in sortList)
            {
                Console.WriteLine("Ten: {0}, so tien phai tra: {1}", hanhKhach.HoTen, hanhKhach.tongTien());
            }
        }
    }
}
