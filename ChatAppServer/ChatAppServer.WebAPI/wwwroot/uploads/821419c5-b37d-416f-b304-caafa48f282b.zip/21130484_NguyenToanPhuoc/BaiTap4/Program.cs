﻿namespace BaiTap04
{
    public delegate int CalculatorDelegate(int num1, int num2);

    class Calculator
    {
        public static int maxNumber(int num1, int num2)
        {
            return num1 > num2 ? num1 : num2;
        }

        public static int addNumber(int num1, int num2)
        {
            return num1 + num2;
        }

        public static int subNumber(int num1, int num2)
        {
            return num1 - num2; 
        }

        public static int multiNumber(int num1, int num2)
        {
            return num1 * num2;
        }

        public static int divNumber(int num1, int num2)
        {
            if (num2 == 0)
            {
                Console.WriteLine("Khong the chia cho 0");
                return -1;
            }

            return num1 / num2;
        }
        public static void Main(string[] args)
        {
            CalculatorDelegate caculatorMaxNumber = new CalculatorDelegate(maxNumber); 
            CalculatorDelegate caculatorAddNumber = new CalculatorDelegate(addNumber);
            CalculatorDelegate caculatorSubNumber = new CalculatorDelegate(subNumber);
            CalculatorDelegate caculatorMultiNumber = new CalculatorDelegate(multiNumber);
            CalculatorDelegate caculatorDivNumber = new CalculatorDelegate(divNumber);

            Console.Write("Nhap so thu 1: ");
            int num1 = int.Parse(Console.ReadLine());
            Console.Write("Nhap so thu 2: ");
            int num2 = int.Parse(Console.ReadLine());

            Console.WriteLine("So lon nhat: {0}", caculatorMaxNumber(num1,num2));
            Console.WriteLine("Cong 2 so: {0}", caculatorAddNumber(num1, num2));
            Console.WriteLine("Tru 2 so: {0}", caculatorSubNumber(num1, num2));
            Console.WriteLine("Nhan 2 so: {0}", caculatorMultiNumber(num1, num2));
            Console.WriteLine("Chia 2 so: {0}", caculatorDivNumber(num1, num2));



        }
    }
}