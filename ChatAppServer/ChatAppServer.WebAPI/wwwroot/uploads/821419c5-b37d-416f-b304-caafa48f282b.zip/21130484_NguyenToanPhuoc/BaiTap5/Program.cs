﻿using System.Text.RegularExpressions;

namespace BaiTap05
{
    class BaiTap05
    {
        public static List<string> danhSachBienSoXe(String str)
        {
            Regex regex = new Regex(@"\d{2}[A-Z]{1}\d\s\d{5}");
            List<string> list = new List<string>();
            foreach(Match match in regex.Matches(str))
            {
                list.Add(match.ToString());
            }
            return list;
        }

        public static void layThongTin(String str)
        {
            Regex regex = new Regex(@"(?<times>(\d|:)+)\s(?<company>\S+)\s(?<ip>(\d|\.)+)");
            foreach (Match match in regex.Matches(str))
            {
                Console.WriteLine("time: " + match.Groups["times"]);
                Console.WriteLine("company: " +match.Groups["company"]);
                Console.WriteLine("ip: " + match.Groups["ip"]);
                Console.WriteLine();
            }
        }

        public static void Main(String[] args)
        {
            string str = "Biển số xe: 59A5 12345, địa chỉ: 123 Đường ABC, số điện thoại: 0123456789, biển số khác 50B1 67890";
            foreach(string bienso in danhSachBienSoXe(str))
            {
                Console.WriteLine(bienso);
            }

            string str2 = "10:30:15 IBM 192.168.1.2 10:20:15 INTEL 172.168.1.3  15:30:15 SAMSUNG 172.16.1.2";
            layThongTin (str2);
        }
    }
}