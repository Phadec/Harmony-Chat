﻿namespace BaiTap06
{
    class BaiTap06
    {
        public static bool deleteAllFile(string path)
        {
            string[] files = Directory.GetFiles(path);
            foreach(string file in files)
            {
               File.Delete(file);
            }

            string[] dirs = Directory.GetDirectories(path);
            foreach(string dir in dirs)
            {
                deleteAllFile(dir);
                Directory.Delete(dir);
            }

            return true;
        }

        public static void findAll(string path, string extension)
        {
            string[] files = Directory.GetFiles(path);
            foreach(string file in files)
            {
                if (Path.GetExtension(file).Equals(extension, StringComparison.OrdinalIgnoreCase))
                {
                    Console.WriteLine("File: " + Path.GetFileName(file));
                }
            }

            string[] dirs = Directory.GetDirectories(path);
            foreach (string dir in dirs)
            {
                findAll(dir, extension);
            }

        }

        public static void Main(string[] args)
        {
           string path = "C:\\Users\\Hieu\\Desktop\\New folder (2)";
            // Console.WriteLine(deleteAllFile(path));
            findAll(path, ".png");
        }

    }
}
