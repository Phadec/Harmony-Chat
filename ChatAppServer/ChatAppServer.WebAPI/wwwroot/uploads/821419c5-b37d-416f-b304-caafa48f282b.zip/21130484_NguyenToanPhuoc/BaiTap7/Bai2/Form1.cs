﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BaiTap07_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox1.Focus();
            textBox1.TextChanged += textBox1_TextChanged;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // Cập nhật giá trị của lblLapTrinh với nội dung trong txtNhapTen
            textBox2.Text = textBox1.Text;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                textBox2.ForeColor = Color.Green;
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                textBox2.ForeColor = Color.Red;
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked)
            {
                textBox2.ForeColor = Color.Blue;
            }
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton4.Checked)
            {
                textBox2.ForeColor = Color.Black;
            }
        }

        private void UpdateFontStyle()
        {
            FontStyle fontStyle = FontStyle.Regular;
            if (checkBox1.Checked)
            {
                fontStyle |= FontStyle.Bold;
            }
            if (checkBox2.Checked)
            {
                fontStyle |= FontStyle.Italic;
            }
            if (checkBox3.Checked)
            {
                fontStyle |= FontStyle.Underline;
            }

            textBox2.Font = new Font(textBox2.Font, fontStyle);
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            UpdateFontStyle();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            UpdateFontStyle();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            UpdateFontStyle();
        }
    }
}
